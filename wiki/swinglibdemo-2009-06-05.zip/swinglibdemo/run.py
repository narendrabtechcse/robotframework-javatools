#!/usr/bin/env python

import os
import sys
from glob import glob

dir = os.path.dirname(__file__)    

def set_classpath():
    jars = glob(os.path.join(dir, 'lib', '*.jar'))
    classes = os.path.join(dir, 'target', 'classes')
    classpath = jars
    classpath.append(classes)
    os.environ['CLASSPATH'] = os.pathsep.join(classpath)

def run_jybot(args):
    os.system('jybot --outputdir %s %s' % (os.path.join(dir, 'results'), ' '.join(args)))

if __name__ == '__main__':
    set_classpath()
    run_jybot(sys.argv[1:])
