package org.robotframework.registration;

import java.util.ArrayList;
import java.util.List;

public class InMemoryDao implements PersonDao {
    private List people;

    public InMemoryDao() {
        people = new ArrayList();
    }

    public void save(Person person) {
        people.add(person);
    }

    public List findAll() {
        return people;
    }

    public boolean exists(Person person) {
        return people.contains(person);
    }

    public boolean remove(Person person) {
        return people.remove(person);
    }

    public boolean exists(String email) {
        for (int i = 0; i < people.size(); i++)
            if (((Person) people.get(i)).getEmail().equals(email))
                return true;

        return false;
    }
}
