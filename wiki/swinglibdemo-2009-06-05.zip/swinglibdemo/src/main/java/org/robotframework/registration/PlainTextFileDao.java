package org.robotframework.registration;

import java.io.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class PlainTextFileDao implements PersonDao {
    private File file;

    public PlainTextFileDao(String filename) throws IOException {
        file = new File(filename);
        file.createNewFile();
    }

    protected File getFile() {
        return file;
    }

    public void save(Person person) {
        try {
            FileWriter writer = new FileWriter(file, true);
            writer.write(person.getName());
            writer.write("|");
            writer.write(person.getEmail());
            writer.write("\r\n");
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public List findAll() {
        List list = new ArrayList();
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
            String line;
            while ((line = reader.readLine()) != null) {
                String stringArray[] = line.split("\\|");
                list.add(new Person(stringArray[0], stringArray[1]));
            }
            reader.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public boolean exists(Person person) {
        List list = findAll();
        return list.contains(person);
    }

    public boolean remove(Person person) {
        List list = findAll();
        if (!list.contains(person))
            return false;
        file.delete();
        list.remove(person);
        if (list.isEmpty())
            try {
                file.createNewFile();
                return true;
            } catch (IOException e) {
                e.printStackTrace();
            }
        for (Iterator i = list.iterator(); i.hasNext(); save((Person) i.next()));
        return true;
    }

    public boolean exists(String email) {
        List people = findAll();
        for (int i = 0; i < people.size(); i++)
            if (((Person) people.get(i)).getEmail().equals(email))
                return true;

        return false;
    }
}
