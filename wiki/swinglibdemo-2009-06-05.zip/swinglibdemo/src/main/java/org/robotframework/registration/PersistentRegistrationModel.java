package org.robotframework.registration;

import java.util.List;

public class PersistentRegistrationModel implements RegistrationModel {
    private PersonDao dao;
    
    public List getRegistrations() {
        return dao.findAll();
    }

    public void add(Person person) {
        dao.save(person);
    }

    public void remove(Person person) {
        if (!dao.remove(person))
            throw new IllegalArgumentException();
        else
            return;
    }

    public void setPersonDao(PersonDao dao) {
        this.dao = dao;
    }

    public boolean exists(String email) {
        return dao.exists(email);
    }

    public boolean exists(Person person) {
        return dao.exists(person);
    }
}
