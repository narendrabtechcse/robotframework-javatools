package org.robotframework.registration;

import java.io.IOException;

import javax.swing.SwingUtilities;

public class Main {
	private static boolean showSplash = false;
    public static void main(final String args[]) throws Exception {
    	if (args.length == 1 && args[0].equals("splash"))
    		showSplash = true;
    	
    	PersistentRegistrationModel model = new PersistentRegistrationModel();
        try {
            model.setPersonDao(new PlainTextFileDao("./database.txt"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        final RegistrationView view = new RegistrationView();
        view.setRegistrationModel(model);
        final SplashScreen splashScreen = new SplashScreen();
        
        if (showSplash)
        	splashScreen.showSplash();
        
        SwingUtilities.invokeLater(new Runnable() {
        	public void run() {
        		if (showSplash) {
        			sleep(5);
        			splashScreen.dispose();
        		}
        		view.launch();
            }
        });
    }
    
    private static void sleep(int seconds) {
    	try {
			Thread.sleep(seconds * 1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
    }
}
