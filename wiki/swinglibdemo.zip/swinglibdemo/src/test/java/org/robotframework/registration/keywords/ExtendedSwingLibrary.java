package org.robotframework.registration.keywords;

import java.util.ArrayList;

import org.robotframework.swing.SwingLibrary;

public class ExtendedSwingLibrary extends SwingLibrary{
	public ExtendedSwingLibrary() {
		super(new ArrayList() {{ add("org/robotframework/registration/keywords/**.class"); }});
	}
}
