package org.robotframework.registration.keywords;

import java.awt.Graphics;
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.HeadlessException;
import java.awt.Image;
import java.awt.Transparency;
import java.awt.image.BufferedImage;

import javax.swing.ImageIcon;

import org.netbeans.jemmy.operators.ContainerOperator;
import org.netbeans.jemmy.operators.JButtonOperator;
import org.netbeans.jemmy.operators.JLabelOperator;
import org.robotframework.javalib.annotation.RobotKeyword;
import org.robotframework.javalib.annotation.RobotKeywords;
import org.robotframework.swing.chooser.ByNameOrTextComponentChooser;
import org.robotframework.swing.context.Context;

@RobotKeywords
public class MyKeywords {
	@RobotKeyword
	public String getTooltipText(String componentIdentifier) {
		JButtonOperator buttonOperator = new JButtonOperator((ContainerOperator)Context.getContext(), new ByNameOrTextComponentChooser(componentIdentifier));
		return buttonOperator.getToolTipText();
	}
	
	@RobotKeyword
	public int[] getColorCode(String identifier) {
		JLabelOperator labelOperator = new JLabelOperator((ContainerOperator) Context.getContext(), new ByNameOrTextComponentChooser(identifier));
		ImageIcon icon = (ImageIcon) labelOperator.getIcon();
		BufferedImage bufferedImage = toBufferedImage(icon.getImage());
		int rgb = bufferedImage.getRGB(0, 0);
		return new int[] { getRed(rgb), getGreen(rgb), getBlue(rgb) };
	}
	
	private int getRed(int rgb) {
		return (rgb >>> 16) & 0xFF;
	}
	
	private int getGreen(int rgb) {
		return (rgb >>> 8) & 0xFF;
	}
	private int getBlue(int rgb) {
		return (rgb >>> 0) & 0xFF;
	}
	
    private BufferedImage toBufferedImage(Image image) {
        if (image instanceof BufferedImage) {
            return (BufferedImage)image;
        }
    
        image = new ImageIcon(image).getImage();
    
        BufferedImage bimage = null;
        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        try {
            int transparency = Transparency.OPAQUE;
    
            GraphicsDevice gs = ge.getDefaultScreenDevice();
            GraphicsConfiguration gc = gs.getDefaultConfiguration();
            bimage = gc.createCompatibleImage(
                image.getWidth(null), image.getHeight(null), transparency);
        } catch (HeadlessException e) {
            // The system does not have a screen
        }
    
        if (bimage == null) {
            int type = BufferedImage.TYPE_INT_RGB;
            bimage = new BufferedImage(image.getWidth(null), image.getHeight(null), type);
        }
    
        Graphics g = bimage.createGraphics();
    
        g.drawImage(image, 0, 0, null);
        g.dispose();
    
        return bimage;
    }

}
