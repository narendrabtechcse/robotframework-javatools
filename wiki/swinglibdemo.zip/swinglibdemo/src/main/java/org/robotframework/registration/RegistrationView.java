package org.robotframework.registration;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;
import java.util.Iterator;
import java.util.Vector;

import javax.swing.*;

public class RegistrationView {
    private JFrame registrationFrame;
    private JTextField nameTextfield;
    private JTextField emailTextfield;
    private RegistrationModel model;
    private JLabel numberOfRegistrations;
    private JList registrationList;

    public void setRegistrationModel(RegistrationModel model) {
        this.model = model;
    }

    public void launch() {
        registrationFrame = new JFrame("Registration");
        registrationFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        initContents(registrationFrame.getContentPane());
        registrationFrame.pack();
        registrationFrame.show();
        refresh();
    }

    private void initContents(Container contentPane) {
        BoxLayout layout = new BoxLayout(contentPane, 1);
        contentPane.setLayout(layout);
        contentPane.add(createTopPanel());
        contentPane.add(createBottomPanel());
    }

    private JPanel createBottomPanel() {
        JPanel bottomPanel = new JPanel();
        bottomPanel.setLayout(new BoxLayout(bottomPanel, 0));
        bottomPanel.add(createRegistrationList());
        bottomPanel.add(createButtonPanel());
        return bottomPanel;
    }

    private JPanel createButtonPanel() {
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new BoxLayout(buttonPanel, 1));
        buttonPanel.add(createDeleteButton());
        return buttonPanel;
    }

    private JButton createDeleteButton() {
        JButton button = createButton("delete_button", "Delete");
        button.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                Object selected[] = registrationList.getSelectedValues();
                for (int i = 0; i < selected.length; i++) {
                    Person person = RegistrationView.unformatListString(String.valueOf(selected[i]));
                    model.remove(person);
                }

                refresh();
            }

        });
        return button;
    }

    private JComponent createRegistrationList() {
        registrationList = new JList();
        registrationList.setName("registration_list");
        return freeFloat(enforceMinimumSize(registrationList, new Dimension(300, 300)));
    }

    private JComponent freeFloat(Component component) {
        JPanel panel = new JPanel(new FlowLayout());
        panel.add(component);
        return panel;
    }

    private JComponent enforceMinimumSize(Component list, Dimension size) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Color.RED);
        panel.add(Box.createHorizontalStrut(size.width), "North");
        panel.add(Box.createVerticalStrut(size.height), "East");
        panel.add(list, "Center");
        return panel;
    }

    private JPanel createTopPanel() {
        JPanel topPanel = new JPanel();
        topPanel.setLayout(new BoxLayout(topPanel, 1));
        topPanel.add(createFieldPanel());
        topPanel.add(createAddButton());
        topPanel.add(createSystemExitButton());
//        topPanel.add(createImageLabel());
        return topPanel;
    }

    private Component createImageLabel() {
        ImageIcon icon = createImageIcon("/myimage.png", "myimage");
        JLabel labelWithImage = new JLabel(icon);
        labelWithImage.setName("labelWithImage");
        return labelWithImage;
    }

    private ImageIcon createImageIcon(String path, String description) {
        URL imgURL = getClass().getResource(path);
        return new ImageIcon(imgURL, description);
    }

    private JButton createAddButton() {
        JButton addButton = createButton("add_button", "Add");
        addButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                String name = nameTextfield.getText();
                String email = emailTextfield.getText();
                if (name.length() == 0 && email.length() == 0)
                    createNotificationDialog("Name and email should not be empty!");
                else if (name.length() == 0)
                    createNotificationDialog("Name should not be empty!");
                else if (email.length() == 0)
                    createNotificationDialog("Email should not be empty!");
                else if (email.indexOf("@") == -1)
                    createNotificationDialog("Email address is invalid, it should contain @ character!");
                else if (model.exists(new Person(name, email))) {
                    if (getConfirmation("Registration with given name and email already exists.") == 0)
                        addPerson();
                } else if (model.exists(email)) {
                    if (getConfirmation("Registration with given email already exists.") == 0)
                        addPerson();
                } else {
                    addPerson();
                }
            }

        });
        return addButton;
    }
    
    private JButton createSystemExitButton() {
        JButton addButton = createButton("exit_button", "SystemExit");
        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	System.exit(0);
            }
        });
        return addButton;
    }

    private void addPerson() {
        model.add(new Person(nameTextfield.getText(), emailTextfield.getText()));
        nameTextfield.setText("");
        emailTextfield.setText("");
        refresh();
    }

    private int getConfirmation(String message) {
        String fullMessage = message + " Do you want add the registration?";
        return JOptionPane.showConfirmDialog(registrationFrame, fullMessage, "Confirm Registration Addition", 0);
    }

    private void createNotificationDialog(String notification) {
        JOptionPane.showMessageDialog(registrationFrame, notification, "Notification", 1);
    }

    private void refresh() {
        Vector viewPeople = new Vector();
        java.util.List people = model.getRegistrations();
        Person person;
        for (Iterator i = people.iterator(); i.hasNext(); viewPeople.add(formatListString(person)))
            person = (Person) i.next();

        registrationList.setListData(viewPeople);
        updateNumberOfRegistrations();
    }

    private JPanel createFieldPanel() {
        JPanel fieldPanel = new JPanel(new GridLayout(3, 2));
        nameTextfield = createTextField("name_textfield");
        emailTextfield = createTextField("email_textfield");
        fieldPanel.add(createLabel("name_label", "Name:"));
        fieldPanel.add(nameTextfield);
        fieldPanel.add(createLabel("email_label", "Email:"));
        fieldPanel.add(emailTextfield);
        fieldPanel.add(createLabel("number_of_registrations_label", "Number of registrations:"));
        numberOfRegistrations = createLabel("number_of_registrations_value", "0");
        fieldPanel.add(numberOfRegistrations);
        return fieldPanel;
    }

    private void updateNumberOfRegistrations() {
        numberOfRegistrations.setText(String.valueOf(model.getRegistrations().size()));
    }

    private JButton createButton(String name, String text) {
        JButton button = new JButton();
        button.setName(name);
        button.setText(text);
        button.setToolTipText(text);
        return button;
    }

    private JLabel createLabel(String name, String text) {
        JLabel label = new JLabel();
        label.setName(name);
        label.setText(text);
        return label;
    }

    private JTextField createTextField(String name) {
        JTextField textfield = new JTextField();
        textfield.setName(name);
        textfield.setColumns(30);
        return textfield;
    }

    public static String formatListString(Person person) {
        return formatListString(person.getName(), person.getEmail());
    }

    public static Person unformatListString(String formattedString) {
        String parts[] = formattedString.split("( \\()|(\\))");
        return new Person(parts[0], parts[1]);
    }

    public static String formatListString(String name, String email) {
        return name + " (" + email + ")";
    }
}
