package org.robotframework.registration;

public class Graph {
	public int getStatus() {
		return 1243;
	}
}
