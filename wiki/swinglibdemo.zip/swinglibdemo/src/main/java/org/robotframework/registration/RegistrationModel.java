package org.robotframework.registration;

import java.util.List;

public interface RegistrationModel {
    List getRegistrations();
    void add(Person person);
    boolean exists(Person person);
    boolean exists(String s);
    void remove(Person person);
}
