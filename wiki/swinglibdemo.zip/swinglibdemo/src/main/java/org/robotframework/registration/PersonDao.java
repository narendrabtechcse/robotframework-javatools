package org.robotframework.registration;

import java.util.List;

public interface PersonDao {
    void save(Person person);
    List findAll();
    boolean exists(Person person);
    boolean remove(Person person);
    boolean exists(String s);
}
