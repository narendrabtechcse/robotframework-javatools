#!/usr/bin/env python

import os
import sys
from glob import glob

if __name__ == '__main__':
    dir = os.path.dirname(__file__)
    libdir = os.path.join(dir, 'lib')
    jars = glob(os.path.join(libdir, '*.jar'))
    target = os.path.join(dir, 'target')
    classes = [os.path.join(target, 'classes'), os.path.join(target, 'test-classes')]
    os.environ['CLASSPATH'] = os.pathsep.join(jars + classes)

    outputdir = os.path.join(dir, 'results')
    args = ' '.join(sys.argv[1:])
    command = 'jybot --loglevel TRACE --outputdir "%s" %s' % (outputdir, args)
    os.system(command)
